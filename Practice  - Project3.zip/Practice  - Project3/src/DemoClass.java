
public class DemoClass {
	public void printMessage() {
        System.out.println("Hello, World!");
    }

    // Method with a return value and one argument
    public int square(int num) {
        return num * num;
    }

    // Method with a return value and multiple arguments
    public double calculateArea(int radius, double pi) {
        return pi * radius * radius;
    }

}
