
public class HelloMethod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DemoClass demo = new DemoClass();

        // Calling a method with no return value and no arguments
        demo.printMessage();

        // Calling a method with a return value and one argument
        int result = demo.square(5);
        System.out.println("Square of 5 is: " + result);

        // Calling a method with a return value and multiple arguments
        double area = demo.calculateArea(2, 3.14);
        System.out.println("Area of circle with radius 2 is: " + area);
    }
	}


