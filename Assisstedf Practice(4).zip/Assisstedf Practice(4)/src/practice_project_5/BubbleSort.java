package practice_project_5;
import java.util.Scanner;

public class BubbleSort {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
			// Read the number of elements
			System.out.print("Enter the number of elements: ");
			int n = scanner.nextInt();

			// Read the elements
			int[] arr = new int[n];
			System.out.println("Enter the elements:");
			for (int i = 0; i < n; i++) {
			    arr[i] = scanner.nextInt();
			}

			// Perform bubble sort
			bubbleSort(arr);

			// Print the sorted array
			System.out.println("Sorted array:");
			for (int num : arr) {
			    System.out.print(num + " ");
			}
		}
    }

    public static void bubbleSort(int[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    // Swap arr[j] and arr[j + 1]
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }
}
