package practice_project_7;
import java.util.Scanner;

public class MergeSort {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
			// Read the number of elements
			System.out.print("Enter the number of elements: ");
			int n = scanner.nextInt();

			// Read the elements
			int[] arr = new int[n];
			System.out.println("Enter the elements:");
			for (int i = 0; i < n; i++) {
			    arr[i] = scanner.nextInt();
			}

			// Perform merge sort
			mergeSort(arr, 0, n - 1);

			// Print the sorted array
			System.out.println("Sorted array:");
			for (int num : arr) {
			    System.out.print(num + " ");
			}
		}
    }

    public static void mergeSort(int[] arr, int left, int right) {
        if (left < right) {
            // Find the middle point
            int middle = (left + right) / 2;

            // Sort first and second halves
            mergeSort(arr, left, middle);
            mergeSort(arr, middle + 1, right);

            // Merge the sorted halves
            merge(arr, left, middle, right);
        }
    }

    public static void merge(int[] arr, int left, int middle, int right) {
        // Find sizes of two subarrays to be merged
        int n1 = middle - left + 1;
        int n2 = right - middle;

        // Create temp arrays
        int[] leftArr = new int[n1];
        int[] rightArr = new int[n2];

        // Copy data to temp arrays
        for (int i = 0; i < n1; ++i)
            leftArr[i] = arr[left + i];
        for (int j = 0; j < n2; ++j)
            rightArr[j] = arr[middle + 1 + j];

        // Merge the temp arrays

        // Initial indexes of first and second subarrays
        int i = 0, j = 0;

        // Initial index of merged subarray array
        int k = left;
        while (i < n1 && j < n2) {
            if (leftArr[i] <= rightArr[j]) {
                arr[k] = leftArr[i];
                i++;
            } else {
                arr[k] = rightArr[j];
                j++;
            }
            k++;
        }

        // Copy remaining elements of leftArr[]
        while (i < n1) {
            arr[k] = leftArr[i];
            i++;
            k++;
        }

        // Copy remaining elements of rightArr[]
        while (j < n2) {
            arr[k] = rightArr[j];
            j++;
            k++;
        }
    }
}

