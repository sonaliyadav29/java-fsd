
 class hehe {
int age;
	
	public void process()
	{
		System.out.println("In process");
	}
	
//	class B
//	{
//		public void config()
//		{
//			System.out.println("in config");
//		}
//	}
	
	static class hihi
	{
		public void config()
		{
			System.out.println("In configuration");
		}
	}
}
