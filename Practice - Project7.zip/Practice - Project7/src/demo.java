
public class demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		hehe obj=new hehe();
    	obj.process();
    	
//    	A.B obj1=obj.new B();
//    	obj1.config();
    	
    	hehe.hihi obj1=new hehe.hihi();
    	obj1.config();

	}

}
