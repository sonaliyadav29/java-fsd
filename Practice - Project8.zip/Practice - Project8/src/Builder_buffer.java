
 class Builder_buffer {

		 
	 public static void main(String[] args)
	    {
	        // Custom input string
	        String str = "Love";
	 
	        
	        
	        // Converting String object to StringBuffer object
	        StringBuffer sbr = new StringBuffer(str);
	 
	        // Reversing the string
	        sbr.reverse();
	 
	        // Printing the reversed string
	        System.out.println(sbr);
	 
	        
	        
	        // Converting String object to StringBuilder object
	        StringBuilder sbl = new StringBuilder(str);
	 
	        // Adding it using append() method
	        sbl.append(" Java");
	 
	        
	        // Print and display the  appended string
	        System.out.println(sbl);
	    }
	    
	}

