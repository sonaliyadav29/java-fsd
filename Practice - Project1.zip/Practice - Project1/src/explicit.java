
public class explicit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
double d=298.99;

long l= (long)d;

int i = (int)l;
 System.out.println("Before conversion: "+d);
 System.out.println("After converstion into long type: "+l);
	System.out.println("After conversion into int type: "+i);
	}

}
