
public class implicit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a =6;
	      
	    long b= a;
	    
	    float c= b;
	      
	    System.out.println("Before Casting Original Value: "+ a);
	    System.out.println("After Casting to long:  "+ b);
	    System.out.println("After casting to float:  "+ c);
	}

}
