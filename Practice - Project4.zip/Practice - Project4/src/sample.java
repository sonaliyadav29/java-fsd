
public class sample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person obj=new Person();
		Person obj1=new Person();
		System.out.println(obj.getName()+" : "+obj.getAge());
		
		obj.SetAge(30);
		obj.setName("Reddy");
		

		//System.out.println(obj.getName()+" : "+obj.getAge());
	}

}
