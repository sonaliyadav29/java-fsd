package collections;
import java.util.*;
public class collection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("ArrayList");
		ArrayList<String> list=new ArrayList<String>(); 
		list.add("Sona");
		list.add("Amu");  
		list.add("Riya");  
		list.add("Ajay");  
		System.out.println(list);
		
		 System.out.println("\n");
		 System.out.println("Vector");
		 Vector<String> v=new Vector<String>();  
		 v.add("Ayushi");  
		 v.add("Shashank");  
		 v.add("Shiya");  
		 v.add("Shanaya");  
		 System.out.println(v);
		 

		 System.out.println("\n");
		 System.out.println("Linked List");
		 LinkedList<String> al=new LinkedList<String>();  
		 al.add("Sona");  
		 al.add("Amu");  
		 al.add("Ravi");  
		 al.add("Ajay"); 
		 Iterator<String> itr=al.iterator();  
		 while(itr.hasNext()){  
		 System.out.println(itr.next());  
		 
		 System.out.println("\n");
	       System.out.println("Hash Set");
	       HashSet<Integer> set=new HashSet<Integer>();  
	       set.add(1);  
	       set.add(2);  
	       set.add(3);
	       set.add(4);
	       System.out.println(set);
	       
	       System.out.println("\n");
	       System.out.println("Linked Hash Set");
	       LinkedHashSet<String> set1=new LinkedHashSet<String>();  
	       set1.add("Ravi");  
	       set1.add("Jay");  
	       set1.add("Shashank");  
	       set1.add("Ajay");  
	       System.out.println(set1);
		 
		}  
	}

}
